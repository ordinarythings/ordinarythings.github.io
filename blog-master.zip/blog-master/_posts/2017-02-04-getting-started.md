---
layout: post
title: Getting Started
---

This is a very simple Jekyll theme focused on content. The theme consists of a header and a list of posts. Every aspect of the theme can be changed by editing the `_config.yml` & `_data/navigation.yml` files.

If you have any questions or difficulties setting up your blog, [email me](mailto:micahcowell@gmail.com) or submit an issue to [Github](https://github.com/getmicah/blog/issues).
